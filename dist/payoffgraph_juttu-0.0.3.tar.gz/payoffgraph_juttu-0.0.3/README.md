# Get the most beautiful Payoff Chart using a single simple function


## Usage

- Make sure you have Python installed in your system.
- Run Following command in the CMD.
 ```
  pip install payoffgraph-juttu
  ```